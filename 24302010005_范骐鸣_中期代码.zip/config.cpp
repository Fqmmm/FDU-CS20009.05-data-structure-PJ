#include "config.h"

// BPR 函数参数默认值
double BPRConfig::alpha = 0.15;
double BPRConfig::beta = 4.0;
double BPRConfig::lane_capacity = 1800.0;
